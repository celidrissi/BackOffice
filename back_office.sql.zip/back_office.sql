-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost:8889
-- Généré le :  Dim 12 juil. 2020 à 18:55
-- Version du serveur :  5.7.25
-- Version de PHP :  7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `back_office`
--

-- --------------------------------------------------------

--
-- Structure de la table `companies`
--

CREATE TABLE `companies` (
  `id` int(11) NOT NULL,
  `name` varchar(30) NOT NULL,
  `department` tinyint(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='List of companies';

--
-- Déchargement des données de la table `companies`
--

INSERT INTO `companies` (`id`, `name`, `department`) VALUES
(1, 'Apple', 59),
(2, 'Microsoft', 75),
(3, 'Facebook', 75),
(4, 'Thirard', 80),
(5, 'DessineTonMeuble', 60),
(6, 'Google', 75),
(7, 'Amazon', 80),
(8, 'Hippocampe', 75),
(9, 'Webedia', 92),
(10, 'OVH', 59),
(11, 'Leboncoin', 75),
(12, 'Veepee', 93),
(13, 'SeLoger', 75),
(14, 'Cdiscount', 33),
(15, 'Netflix', 75),
(21, 'Samsung', 75);

-- --------------------------------------------------------

--
-- Structure de la table `employees`
--

CREATE TABLE `employees` (
  `id` int(11) NOT NULL,
  `id_company` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `age` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `employees`
--

INSERT INTO `employees` (`id`, `id_company`, `name`, `first_name`, `age`) VALUES
(1, 1, 'Briet', 'Emilien', 28),
(2, 2, 'Dubus', 'James', 42),
(3, 15, 'Bourdeaud\'hui', 'Joah', 5),
(4, 4, 'El idrissi', 'Chafik', 24),
(5, 2, 'Bortoletto', 'Pascal', 40),
(6, 6, 'Vermeulen', 'Pascal', 35),
(7, 7, 'Poirot', 'Tatiana', 23),
(8, 8, 'Renson', 'Ludovic', 45),
(9, 9, 'Masson', 'Antoine', 27),
(10, 10, 'Jaud', 'Severine', 40),
(11, 11, 'Huignez', 'Jean-Michel', 44),
(12, 12, 'Defert', 'Camille', 25),
(13, 13, 'Detambel', 'Eliott', 18),
(14, 14, 'Deloffre', 'Benoit', 45),
(15, 3, 'Lhomme', 'Hugette', 85),
(20, 2, 'Bill', 'Gates', 64),
(21, 2, 'Paul', 'Allen', 65),
(22, 7, 'Jeff', 'Bezos', 56),
(23, 3, 'Mark', 'zuckerberg', 36),
(24, 1, 'Tim', 'Cook', 59),
(25, 1, 'Steve', 'Jobs', 56),
(26, 1, 'Steve', 'Wozniak', 69),
(27, 14, 'Emannuel', 'Grenier', 48),
(28, 6, 'Larry', 'Page', 47),
(29, 5, 'Yann', 'Portier', 45);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `companies`
--
ALTER TABLE `companies`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `companies`
--
ALTER TABLE `companies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT pour la table `employees`
--
ALTER TABLE `employees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
